import os


def read_file(file_path: str) -> str:

    if not os.path.isfile(file_path):
        raise ValueError(f"{file_path} is not a file.")
    with open(file_path, 'r') as file:
        return file.read()



def compute_jaccard_similarity(a: str, b: str) -> float:

    a_content = read_file(a).splitlines()
    b_content = read_file(b).splitlines()
    a = set(a_content)
    b = set(b_content)
    return len(a & b) / len(a | b)





def visualise_dot_plot(a: str, b: str) -> str:
    
    a_content = read_file(a).splitlines()
    b_content = read_file(b).splitlines()

    plot = '-' * 80 + '\n'
    for i in range(len(a_content)):
        plot += f'x{i}: {a_content[i]}\n'
    plot += '-' * 80 + '\n'
    for j in range(len(b_content)):
        plot += f'y{j}: {b_content[j]}\n'
    plot += '-' * 80 + '\n'


    plot += '\t'
    # Plot the x labels
    for i in range(len(a_content)):
        plot += f"x{i}\t"
    plot += '\n'
    # Plot the y labels and the dots
    for j in range(len(b_content)):
        plot += f"y{j}\t"
        # Place a '*' where lines match, space otherwise
        for i in range(len(a_content)):
            if a_content[i] == b_content[j]:
                plot += f"*\t"
            else:
                plot += f" \t"
        plot += '\n'
    plot += '-' * 80
    print(plot.strip())
    return plot.strip()