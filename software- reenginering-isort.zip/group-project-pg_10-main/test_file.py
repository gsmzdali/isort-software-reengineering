# sort/check APIs & future import handling
from __future__ import abs_import

# unsorted stdlib / third-party block
import os
import pathlib
# duplicate imports for check_* APIs
import sys

import requests
# wrap_modes
from third_party import (lib1, lib2, lib3,  # inline comment; inline comment 2
                         lib4, lib5, lib6, lib7, lib8, lib9, lib10, lib11,
                         lib13, lib14, lib15)

# code
x = 1
y = 2

print("Hey")
print("hello")

# already-sorted block
from collections import OrderedDict, defaultdict
# as-import handling
from os import path as os_path
from sys import argv as sys_argv

# known third-party modules for placement test
import numpy
import pandas
# varied import styles for identify/find_imports APIs
from my_lib import Object2  # inline comment 3
from my_lib import Object, Object3


# indented imports for identify.imports
def func():
    import os
    from collections import OrderedDict


