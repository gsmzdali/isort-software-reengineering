from . import sorting  # noqa: PLC0415
from .exceptions import SortingFunctionDoesNotExist  # noqa: PLC0415
# from .settings import entry_points  # noqa: PLC0415
from collections.abc import Callable
from typing import Any


# Moved from .settings to avoid circular import
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from importlib.metadata import EntryPoints


def entry_points(group: str) -> "EntryPoints":
    """Call entry_point after lazy loading it.

    TODO: The reason for lazy loading here are unknown.
    """
    from importlib.metadata import entry_points as ep  # noqa: PLC0415

    return ep(group=group)





"""Sort function for isort.

Extracted from Config as a provider class following RP2 and RP4. The sort_order field and sorting_function property previously existed in Config and now exist in this provider
"""
class SortResolver:


    def __init__(self, sort_order: str = "natural") -> None:
        self.sort_order = sort_order
        self._sorting_function: Callable[..., list[str]] | None = None


    @property
    def sorting_function(self) -> Callable[..., list[str]]:
        if self._sorting_function is not None:
            return self._sorting_function

        if self.sort_order == "natural":
            self._sorting_function = sorting.naturally
        elif self.sort_order == "native":
            self._sorting_function = sorted
        else:
            available_sort_orders = ["natural", "native"]
            for sort_plugin in entry_points(group="isort.sort_function"):
                available_sort_orders.append(sort_plugin.name)
                if sort_plugin.name == self.sort_order:
                    self._sorting_function = sort_plugin.load()
                    break
            else:
                raise SortingFunctionDoesNotExist(self.sort_order, available_sort_orders)

        return self._sorting_function




        