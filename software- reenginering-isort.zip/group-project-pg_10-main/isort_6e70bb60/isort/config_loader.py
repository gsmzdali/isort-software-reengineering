"""Configuration loading for isort.

This module centralises the multi-stage loading pipeline that was previously
embedded inside ``Config.__init__``:

  1. Read raw config from a file or directory (``_init_settings_from_existing``)
  2. Layer in any named profile (``_init_load_profile``)
  3. Combine profile + file + runtime overrides into a single dict
  4. Normalise the result (``_handle_indent``, ``_process_known_config_items``,
     ``_handle_src_paths``, ``_apply_formatter_plugin``, ``_remove_config_values``,
     ``_handle_deprecations``, ``_inject_metadata_sections``)
  5. Validate the final dict (``_validate_no_unsupported_keys``)

The ``Config`` class then takes the resolved ``(combined_config, sources)``
tuple and feeds it to its frozen-dataclass parent. Keeping all of this logic
out of ``Config`` is the main step in eliminating the God Class smell.
"""

import os
from pathlib import Path
from typing import Any
from warnings import warn



from .exceptions import (
    FormattingPluginDoesNotExist,
    InvalidSettingsPath,
    ProfileDoesNotExist,
    UnsupportedSettings,
)
from .profiles import profiles as profiles


class ConfigLoader:
    """Resolve isort settings from files, profiles, and runtime overrides.

    Responsibility: produce a fully-merged configuration dictionary plus the
    list of layered sources that fed it. ``ConfigLoader`` does not hold or
    expose isort settings itself - it only constructs the inputs that
    ``Config`` needs to populate its dataclass parent.

    Typical usage::

        loader = ConfigLoader(
            settings_file="pyproject.toml",
            settings_path="",
            config_overrides={"line_length": 100},
        )
        combined_config, sources = loader.load()
    """

    def __init__(
        self,
        settings_file: str = "",
        settings_path: str = "",
        config_overrides: dict[str, Any] | None = None,
    ) -> None:
        self.settings_file = settings_file
        self.settings_path = settings_path
        # Shallow-copy so the loader can freely mutate without affecting the
        # caller's dict (e.g. setting overrides["source"] = RUNTIME_SOURCE).
        self.config_overrides: dict[str, Any] = (
            dict(config_overrides) if config_overrides else {}
        )
        self.quiet: bool = self.config_overrides.get("quiet", False)

    # ----------------------------------------------------------------- public

    def load(self) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        """Run the full loading pipeline.

        Returns a tuple ``(combined_config, sources)`` ready to be passed to
        ``_Config.__init__`` via ``**combined_config`` (with ``sources``
        coerced to a tuple by the caller).
        """
        # Deferred imports avoid a circular dependency: settings.py imports
        # from this module, and we need a few module-level constants/helpers
        # that live in settings.py.
        from .settings import (  # noqa: PLC0415
            _DEFAULT_SETTINGS,
            RUNTIME_SOURCE,
            SECTION_DEFAULTS,
            DEFAULT_SKIP,
            _as_list
        )

        # 1. Read raw config from a file or directory.
        config_settings, project_root = self._init_settings_from_existing(
            self.settings_file, self.settings_path, self.quiet
        )

        # 2. Layer in any named profile.
        sources: list[dict[str, Any]] = [_DEFAULT_SETTINGS]
        profile = self._init_load_profile(self.config_overrides, config_settings)
        sources.append(profile)

        # 3. Combine profile + file + runtime overrides into a single dict
        #    (priority: profile < config file < overrides).
        if config_settings:
            sources.append(config_settings)
        if self.config_overrides:
            self.config_overrides["source"] = RUNTIME_SOURCE
            sources.append(self.config_overrides)

        combined_config: dict[str, Any] = {
            **profile,
            **config_settings,
            **self.config_overrides,
        }


        

        # 4. Normalise.
        combined_config = self._handle_indent(combined_config)
        combined_config, known_other, import_headings, import_footers = self._process_known_config_items(combined_config, self.quiet)


        # 4a. Warn about sections referencing unknown known_* options.
        self._known_other = known_other
        self._import_headings = import_headings
        self._import_footers = import_footers


        # 4b. Default `directory` if the caller didn't supply one.
        if "directory" not in combined_config:
            combined_config["directory"] = (
                os.path.dirname(config_settings["source"])
                if config_settings.get("source", None)
                else os.getcwd()
            )

        combined_config["src_paths"] = self._handle_src_paths(
            combined_config, project_root
        )


        combined_config = self._apply_formatter_plugin(combined_config)
        # Capture file type extension values before stripping them from the config.
        # They are not _Config dataclass fields and are handled separately by Config
        # via FileTypeChecker.
        self.supported_extensions = combined_config.get("supported_extensions", None)
        self.blocked_extensions = combined_config.get("blocked_extensions", None)

        # Store sort_order before stripping to pass to SortResolver by Config
        self.sort_order = combined_config.get("sort_order", "natural")


        def _to_frozenset(val, default):
            if val is None:
                return frozenset(default)
            if isinstance(val, (frozenset, set)):
                return frozenset(val)
            if isinstance(val, (list, tuple)):
                return frozenset(val)
            return frozenset(_as_list(val))

        self.skip = _to_frozenset(combined_config.get("skip"), DEFAULT_SKIP)
        self.extend_skip = _to_frozenset(combined_config.get("extend_skip"), frozenset())
        self.skip_glob = _to_frozenset(combined_config.get("skip_glob"), frozenset())
        self.extend_skip_glob = _to_frozenset(combined_config.get("extend_skip_glob"), frozenset())
        self.skip_gitignore = bool(combined_config.get("skip_gitignore", False))
        self.git_ls_files = combined_config.get("git_ls_files", {})
        self.directory = combined_config.get("directory", "")


        from .settings import IMPORT_HEADING_PREFIX, IMPORT_FOOTER_PREFIX  # noqa: PLC0415
        heading_footer_keys = [
            key for key in combined_config
            if key.startswith(IMPORT_HEADING_PREFIX) or key.startswith(IMPORT_FOOTER_PREFIX)
        ]


        combined_config = self._remove_config_values(
            combined_config,
            ("source", "sources", "runtime_src_paths", "supported_extensions", "blocked_extensions", "skip", "extend_skip", "skip_glob", "extend_skip_glob", "skip_gitignore", "sort_order", *heading_footer_keys),
        )



        combined_config = self._handle_deprecations(combined_config, self.quiet)
        combined_config = self._inject_metadata_sections(combined_config)










        # 5. Validate.

            
        self._validate_no_unsupported_keys(combined_config, sources)

        return combined_config, sources

    # ------------------------------------------------------------- internals
    #
    # The methods below were lifted verbatim from ``Config`` as part of the
    # God Class refactor. They are pure-ish helpers: they do not read any
    # ``_Config`` dataclass fields, only the inputs passed to them. That is
    # what makes them safe to extract.

    def _init_settings_from_existing(self, settings_file, settings_path, quiet):
        from .settings import (  # noqa: PLC0415
            CONFIG_SECTIONS,
            FALLBACK_CONFIG_SECTIONS,
            _find_config,
            _get_config_data,
        )

        if settings_file:
            config_settings = _get_config_data(
                settings_file,
                CONFIG_SECTIONS.get(
                    os.path.basename(settings_file), FALLBACK_CONFIG_SECTIONS
                ),
            )
            project_root = os.path.dirname(settings_file)
            if not config_settings and not quiet:
                warn(
                    f"A custom settings file was specified: {settings_file} but no configuration "
                    "was found inside. This can happen when [settings] is used as the config "
                    "header instead of [isort]. "
                    "See: https://pycqa.github.io/isort/docs/configuration/config_files"
                    "#custom-config-files for more information.",
                    stacklevel=2,
                )
        elif settings_path:
            if not os.path.exists(settings_path):
                raise InvalidSettingsPath(settings_path)

            settings_path = os.path.abspath(settings_path)
            project_root, config_settings = _find_config(settings_path)
        else:
            config_settings = {}
            project_root = os.getcwd()

        return config_settings, project_root

    def _init_load_profile(self, config_overrides, config_settings):
        # from .settings import entry_points  # noqa: PLC0415
        from .sort_resolver import entry_points  # noqa: PLC0415

        profile_name = config_overrides.get(
            "profile", config_settings.get("profile", "")
        )
        profile: dict[str, Any] = {}

        if profile_name:
            if profile_name not in profiles:
                for plugin in entry_points(group="isort.profiles"):
                    profiles.setdefault(plugin.name, plugin.load())

            if profile_name not in profiles:
                raise ProfileDoesNotExist(profile_name)

            profile = profiles[profile_name].copy()
            profile["source"] = f"{profile_name} profile"

        return profile

    def _handle_indent(self, combined_config):
        if "indent" in combined_config:
            indent = str(combined_config["indent"])
            if indent.isdigit():
                indent = " " * int(indent)
            else:
                indent = indent.strip("'").strip('"')
                if indent.lower() == "tab":
                    indent = "\t"
            combined_config["indent"] = indent
        return combined_config

    def _process_known_config_items(self, combined_config, quiet):
        from .settings import (  # noqa: PLC0415
            _DEFAULT_SETTINGS,
            IMPORT_FOOTER_PREFIX,
            IMPORT_HEADING_PREFIX,
            SECTION_DEFAULTS,
        )
        from .pattern_matcher import KNOWN_PREFIX, KNOWN_SECTION_MAPPING  # noqa: PLC0415

        known_other: dict[str, frozenset[str]] = {}
        import_headings: dict[str, str] = {}
        import_footers: dict[str, str] = {}

        for key, value in tuple(combined_config.items()):
            # Collect all known sections beyond those that have direct entries
            if key.startswith(KNOWN_PREFIX) and key not in (
                "known_standard_library",
                "known_future_library",
                "known_third_party",
                "known_first_party",
                "known_local_folder",
            ):
                import_heading = key[len(KNOWN_PREFIX):].lower()
                maps_to_section = import_heading.upper()
                combined_config.pop(key)
                if maps_to_section in KNOWN_SECTION_MAPPING:
                    section_name = (
                        f"known_{KNOWN_SECTION_MAPPING[maps_to_section].lower()}"
                    )
                    if section_name in combined_config and not quiet:
                        warn(
                            f"Can't set both {key} and {section_name} in the same config file.\n"
                            f"Default to {section_name} if unsure."
                            "\n\n"
                            "See: https://pycqa.github.io/isort/"
                            "#custom-sections-and-ordering.",
                            stacklevel=2,
                        )
                    else:
                        combined_config[section_name] = frozenset(value)
                else:
                    known_other[import_heading] = frozenset(value)
                    if (
                        maps_to_section not in combined_config.get("sections", ())
                        and not quiet
                    ):
                        warn(
                            f"`{key}` setting is defined, but {maps_to_section} is not"
                            " included in `sections` config option:"
                            f" {combined_config.get('sections', SECTION_DEFAULTS)}.\n\n"
                            "See: https://pycqa.github.io/isort/"
                            "#custom-sections-and-ordering.",
                            stacklevel=2,
                        )

            if key.startswith(IMPORT_HEADING_PREFIX):
                import_headings[key[len(IMPORT_HEADING_PREFIX):].lower()] = str(value)

            if key.startswith(IMPORT_FOOTER_PREFIX):
                import_footers[key[len(IMPORT_FOOTER_PREFIX):].lower()] = str(value)

            # Coerce all provided config values into their correct type
            default_value = _DEFAULT_SETTINGS.get(key, None)
            if default_value is None:
                continue


            SKIP_RULE_FIELDS = {
                "skip",
                "extend_skip",
                "skip_glob",
                "extend_skip_glob",
                "skip_gitignore",
                "git_ls_files",
            }

            if key in SKIP_RULE_FIELDS:
                continue
            
            combined_config[key] = type(default_value)(value)

        return combined_config, known_other, import_headings, import_footers




    def _handle_src_paths(self, combined_config, project_root):
        path_root = Path(combined_config.get("directory", project_root)).resolve()
        path_root = path_root if path_root.is_dir() else path_root.parent

        if "src_paths" not in combined_config:
            return (path_root / "src", path_root)

        src_paths: list[Path] = []
        for src_path in combined_config.get("src_paths", ()):
            full_paths = (
                path_root.glob(src_path)
                if "*" in str(src_path)
                else [path_root / src_path]
            )
            for path in full_paths:
                if path not in src_paths:
                    src_paths.append(path)

        return tuple(src_paths)

    def _apply_formatter_plugin(self, combined_config: dict):
        # from .settings import entry_points  # noqa: PLC0415
        from .sort_resolver import entry_points  # noqa: PLC0415

        if "formatter" not in combined_config:
            return combined_config

        formatter_name = combined_config["formatter"]

        for plugin in entry_points(group="isort.formatters"):
            if plugin.name == formatter_name:
                combined_config["formatting_function"] = plugin.load()
                return combined_config

        raise FormattingPluginDoesNotExist(formatter_name)

    def _remove_config_values(self, combined_config: dict, values):
        for key in values:
            combined_config.pop(key, None)
        return combined_config

    def _handle_deprecations(self, combined_config: dict, quiet: bool):
        from .settings import DEPRECATED_SETTINGS  # noqa: PLC0415

        deprecated_options_used = [
            option for option in combined_config if option in DEPRECATED_SETTINGS
        ]

        if deprecated_options_used:
            for deprecated_option in deprecated_options_used:
                combined_config.pop(deprecated_option)
            if not quiet:
                warn(
                    "W0503: Deprecated config options were used: "
                    f"{', '.join(deprecated_options_used)}."
                    "Please see the 5.0.0 upgrade guide: "
                    "https://pycqa.github.io/isort/docs/upgrade_guides/5.0.0.html",
                    stacklevel=2,
                )

        return combined_config


    def _inject_metadata_sections(self, combined_config):
        return combined_config





    def _validate_no_unsupported_keys(self, combined_config, sources):
        from .settings import _Config  # noqa: PLC0415

        unsupported_config_errors = {}
        for option in set(combined_config.keys()).difference(
            getattr(_Config, "__dataclass_fields__", {}).keys()
        ):
            for source in reversed(sources):
                if option in source:
                    unsupported_config_errors[option] = {
                        "value": source[option],
                        "source": source["source"],
                    }
        if unsupported_config_errors:
            raise UnsupportedSettings(unsupported_config_errors)
