
import fnmatch
import os
import posixpath
from pathlib import Path


class SkipRules:
    """Apply skip, skip_glob, and gitignore-based skip rules."""



    def __init__(self) -> None:
        # default values previously owned by Config
        self.skip: frozenset[str] = frozenset()
        self.extend_skip: frozenset[str] = frozenset()
        self.skip_glob: frozenset[str] = frozenset()
        self.extend_skip_glob: frozenset[str] = frozenset()
        self.skip_gitignore: bool = False
        self.git_ls_files: dict[Path, set[str]] = {}
        self.directory: str = ""

        self._skips: frozenset[str] | None = None
        self._skip_globs: frozenset[str] | None = None


    def configure(
        self,
        skip: frozenset,
        extend_skip: frozenset,
        skip_glob: frozenset,
        extend_skip_glob: frozenset,
        skip_gitignore: bool,
        git_ls_files: dict,
        directory: str,
    ) -> None:
        """Set all skip fields at once and clear the merged-set cache."""
        self.skip = frozenset(skip)
        self.extend_skip = frozenset(extend_skip)
        self.skip_glob = frozenset(skip_glob)
        self.extend_skip_glob = frozenset(extend_skip_glob)
        self.skip_gitignore = skip_gitignore
        self.git_ls_files = git_ls_files
        self.directory = directory
        self._skips = None
        self._skip_globs = None
        

    @property
    def skips(self) -> frozenset[str]:
        """Merged set of all skip patterns (skip + extend_skip)."""
        if self._skips is None:
            self._skips = self.skip.union(self.extend_skip)
        return self._skips

    @property
    def skip_globs(self) -> frozenset[str]:
        """Merged set of all skip glob patterns (skip_glob + extend_skip_glob)."""
        if self._skip_globs is None:
            self._skip_globs = self.skip_glob.union(self.extend_skip_glob)
        return self._skip_globs



    def _check_folder_git_ls_files(self, folder: str) -> Path | None:
        # Delegate to git helper to find the nearest tracked git folder
        from .git_tracked_files import check_folder_git_ls_files

        return check_folder_git_ls_files(folder, self.git_ls_files)

    def is_skipped(self, file_path: Path) -> bool:
        """Returns True if the file and/or folder should be skipped."""
        # Resolve path relative to project directory if possible
        if self.directory and Path(self.directory) in file_path.resolve().parents:
            file_name = os.path.relpath(file_path.resolve(), self.directory)
        else:
            file_name = str(file_path)

        os_path = str(file_path)

        # remove Windows line separators for comparison
        normalized_path = os_path.replace("\\", "/")
        if normalized_path[1:2] == ":":
            normalized_path = normalized_path[2:]

        # Check if the file matches any exact skip path
        for skip_path in self.skips:
            if posixpath.abspath(normalized_path) == posixpath.abspath(
                skip_path.replace("\\", "/")
            ):
                return True


        # Search directory components checking each against the skip set
        position = os.path.split(file_name)
        while position[1]:
            if position[1] in self.skips:
                return True
            position = os.path.split(position[0])

        for sglob in self.skip_globs:
            if fnmatch.fnmatch(file_name, sglob) or fnmatch.fnmatch("/" + file_name, sglob):
                return True

        if not (os.path.isfile(os_path) or os.path.isdir(os_path) or os.path.islink(os_path)):
            return True

        if self.skip_gitignore:
            if file_path.name == ".git":  # pragma: no cover
                return True

            git_folder = None

            file_paths = [file_path, file_path.resolve()]
            for folder in self.git_ls_files:
                if any(folder in path.parents for path in file_paths):
                    git_folder = folder
                    break
            else:
                git_folder = self._check_folder_git_ls_files(str(file_path.parent))

            if (
                git_folder
                and not file_path.is_dir()
                and str(file_path.resolve()) not in self.git_ls_files[git_folder]
            ):
                return True

        return False