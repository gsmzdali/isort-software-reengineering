import os
import subprocess
from pathlib import Path


def check_folder_git_ls_files(
    folder: str, git_ls_files: dict
) -> Path | None:
    """
    Populate git_ls_files with files tracked by Git for the given folder.
    Returns the root git folder path, or None if not a git repository.
    """
    env = {**os.environ, "LANG": "C.UTF-8"}
    try:
        topfolder_result = subprocess.check_output(  # nosec # skipcq: PYL-W1510
            ["git", "-C", folder, "rev-parse", "--show-toplevel"],
            encoding="utf-8",
            env=env,
        )
    except subprocess.CalledProcessError:
        return None

    git_folder = Path(topfolder_result.rstrip()).resolve()

    # files committed to git
    tracked_files = (
        subprocess.check_output(  # nosec # skipcq: PYL-W1510
            ["git", "-C", str(git_folder), "ls-files", "-z"],
            encoding="utf-8",
            env=env,
        )
        .rstrip("\0")
        .split("\0")
    )
    # files that haven't been committed yet, but aren't ignored
    tracked_files_others = (
        subprocess.check_output(  # nosec # skipcq: PYL-W1510
            ["git", "-C", str(git_folder), "ls-files", "-z",
             "--others", "--exclude-standard"],
            encoding="utf-8",
            env=env,
        )
        .rstrip("\0")
        .split("\0")
    )

    git_ls_files[git_folder] = {
        str(git_folder / Path(f))
        for f in tracked_files + tracked_files_others
    }
    return git_folder