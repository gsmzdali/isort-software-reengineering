"""isort/settings.py.

Defines how the default settings for isort should be loaded
"""
from isort.sort_resolver import SortResolver


import configparser
import os
import re
import subprocess  # nosec # Needed for gitignore support.
import sys
import stat
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from .skip_rules import SkipRules
from .config_loader import ConfigLoader
from pathlib import Path
from re import Pattern
from typing import TYPE_CHECKING, Any
from warnings import warn
from .file_type_checker import FileTypeChecker
from .pattern_matcher import PatternMatcher

from . import sorting, stdlibs
from .exceptions import (
    SortingFunctionDoesNotExist
   
)
from .sections import DEFAULT as SECTION_DEFAULTS
from .sections import FIRSTPARTY, FUTURE, LOCALFOLDER, STDLIB, THIRDPARTY
from .utils import Trie
from .wrap_modes import WrapModes
from .wrap_modes import from_string as wrap_mode_from_string

if TYPE_CHECKING:
    # from importlib.metadata import EntryPoints # Removed as dead code

    tomllib: Any
else:
    if sys.version_info >= (3, 11):
        import tomllib
    else:
        from ._vendored import tomli as tomllib






_SHEBANG_RE = re.compile(rb"^#!.*\bpython[23w]?\b")
CYTHON_EXTENSIONS = frozenset({"pyx", "pxd"})
SUPPORTED_EXTENSIONS = frozenset({"py", "pyi", *CYTHON_EXTENSIONS})
BLOCKED_EXTENSIONS = frozenset({"pex"})





FILE_SKIP_COMMENTS: tuple[str, ...] = (
    "isort:" + "skip_file",
    "isort: " + "skip_file",
)  # Concatenated to avoid this file being skipped
MAX_CONFIG_SEARCH_DEPTH: int = 25  # The number of parent directories to for a config file within
STOP_CONFIG_SEARCH_ON_DIRS: tuple[str, ...] = (".git", ".hg")
VALID_PY_TARGETS: tuple[str, ...] = tuple(
    target.replace("py", "") for target in dir(stdlibs) if not target.startswith("_")
)
CONFIG_SOURCES: tuple[str, ...] = (
    ".isort.cfg",
    "pyproject.toml",
    "setup.cfg",
    "tox.ini",
    ".editorconfig",
)
DEFAULT_SKIP: frozenset[str] = frozenset(
    {
        ".venv",
        "venv",
        ".tox",
        ".eggs",
        ".git",
        ".hg",
        ".mypy_cache",
        ".nox",
        ".svn",
        ".bzr",
        "_build",
        "buck-out",
        "build",
        "dist",
        ".pants.d",
        ".direnv",
        "node_modules",
        "__pypackages__",
        ".pytype",
    }
)

CONFIG_SECTIONS: dict[str, tuple[str, ...]] = {
    ".isort.cfg": ("settings", "isort"),
    "pyproject.toml": ("tool.isort",),
    "setup.cfg": ("isort", "tool:isort"),
    "tox.ini": ("isort", "tool:isort"),
    ".editorconfig": ("*", "*.py", "**.py", "*.{py}"),
}
FALLBACK_CONFIG_SECTIONS: tuple[str, ...] = ("isort", "tool:isort", "tool.isort")

IMPORT_HEADING_PREFIX = "import_heading_"
IMPORT_FOOTER_PREFIX = "import_footer_"




from .pattern_matcher import KNOWN_PREFIX, KNOWN_SECTION_MAPPING


RUNTIME_SOURCE = "runtime"

DEPRECATED_SETTINGS = ("not_skip", "keep_direct_and_as_imports")

_STR_BOOLEAN_MAPPING = {
    "y": True,
    "yes": True,
    "t": True,
    "on": True,
    "1": True,
    "true": True,
    "n": False,
    "no": False,
    "f": False,
    "off": False,
    "0": False,
    "false": False,
}





# Moved these constants to pattern_matcher.py (RP2)
# KNOWN_PREFIX = "known_"
# KNOWN_SECTION_MAPPING: dict[str, str] = {
#     STDLIB: "STANDARD_LIBRARY",
#     FUTURE: "FUTURE_LIBRARY",
#     FIRSTPARTY: "FIRST_PARTY",
#     THIRDPARTY: "THIRD_PARTY",
#     LOCALFOLDER: "LOCAL_FOLDER",
# }





@dataclass(frozen=True)
class _Config:
    py_version: str = "3"
    force_to_top: frozenset[str] = frozenset()

    # Should probably remove these and put in skip_rules, but that is a much larger refactor and this is needed for the config loading refactor to be complete.(Beyond RP4)
    # skip: frozenset[str] = DEFAULT_SKIP
    # extend_skip: frozenset[str] = frozenset()
    # skip_glob: frozenset[str] = frozenset()
    # extend_skip_glob: frozenset[str] = frozenset()
    # skip_gitignore: bool = False
    # git_ls_files: dict[Path, set[str]] = field(default_factory=dict)
    # directory: str = ""

    skip_rules: SkipRules = field(default_factory=SkipRules)
    directory: str = ""
    git_ls_files: dict[Path, set[str]] = field(default_factory=dict)


    # Move these out of Config and into PatternMatcher (RP2).
    # import_headings: dict[str, str] = field(default_factory=dict)
    # import_footers: dict[str, str] = field(default_factory=dict)
    sections: tuple[str, ...] = SECTION_DEFAULTS
    # known_other: dict[str, frozenset[str]] = field(default_factory=dict)


    # Moved into FileTypeChecker class (RP2).
    # supported_extensions: frozenset[str] = SUPPORTED_EXTENSIONS
    # blocked_extensions: frozenset[str] = BLOCKED_EXTENSIONS



    # Moved to SortResolver provider class (RP2)
    # sort_order: str = "natural"
    sort_resolver: SortResolver = field(default_factory=SortResolver)


    line_length: int = 79
    wrap_length: int = 0
    line_ending: str = ""
    
    no_sections: bool = False
    known_future_library: frozenset[str] = frozenset(("__future__",))
    known_third_party: frozenset[str] = frozenset()
    known_first_party: frozenset[str] = frozenset()
    known_local_folder: frozenset[str] = frozenset()
    known_standard_library: frozenset[str] = frozenset()
    extra_standard_library: frozenset[str] = frozenset()
    
    multi_line_output: WrapModes = WrapModes.GRID  # type: ignore
    forced_separate: tuple[str, ...] = ()
    indent: str = " " * 4
    comment_prefix: str = "  #"
    length_sort: bool = False
    length_sort_straight: bool = False
    length_sort_sections: frozenset[str] = frozenset()
    add_imports: frozenset[str] = frozenset()
    remove_imports: frozenset[str] = frozenset()
    append_only: bool = False
    reverse_relative: bool = False
    force_single_line: bool = False
    single_line_exclusions: tuple[str, ...] = ()
    default_section: str = THIRDPARTY

    balanced_wrapping: bool = False
    use_parentheses: bool = False
    order_by_type: bool = True
    atomic: bool = False
    lines_before_imports: int = -1
    lines_after_imports: int = -1
    lines_between_sections: int = 1
    lines_between_types: int = 0
    combine_as_imports: bool = False
    combine_star: bool = False
    include_trailing_comma: bool = False
    from_first: bool = False
    verbose: bool = False
    quiet: bool = False
    force_adds: bool = False
    force_alphabetical_sort_within_sections: bool = False
    force_alphabetical_sort: bool = False
    force_grid_wrap: int = 0
    force_sort_within_sections: bool = False
    lexicographical: bool = False
    group_by_package: bool = False
    ignore_whitespace: bool = False
    no_lines_before: frozenset[str] = frozenset()
    no_inline_sort: bool = False
    ignore_comments: bool = False
    case_sensitive: bool = False
    sources: tuple[dict[str, Any], ...] = ()
    virtual_env: str = ""
    conda_env: str = ""
    ensure_newline_before_comments: bool = False
    
    profile: str = ""
    honor_noqa: bool = False
    src_paths: tuple[Path, ...] = ()
    remove_redundant_aliases: bool = False
    float_to_top: bool = False
    filter_files: bool = False
    formatter: str = ""
    formatting_function: Callable[[str, str, object], str] | None = None
    color_output: bool = False
    treat_comments_as_code: frozenset[str] = frozenset()
    treat_all_comments_as_code: bool = False

    constants: frozenset[str] = frozenset()
    classes: frozenset[str] = frozenset()
    variables: frozenset[str] = frozenset()
    dedup_headings: bool = False
    only_sections: bool = False
    only_modified: bool = False
    combine_straight_imports: bool = False
    auto_identify_namespace_packages: bool = True
    namespace_packages: frozenset[str] = frozenset()
    follow_links: bool = True
    indented_import_headings: bool = True
    honor_case_in_force_sorted_sections: bool = False
    sort_relative_in_force_sorted_sections: bool = False
    overwrite_in_place: bool = False
    reverse_sort: bool = False
    star_first: bool = False
    import_dependencies = dict[str, str]
    
    format_error: str = "{error}: {message}"
    format_success: str = "{success}: {message}"
    
    sort_reexports: bool = False
    split_on_trailing_comma: bool = False

    def __post_init__(self) -> None:
        py_version = self.py_version
        if py_version == "auto":  # pragma: no cover
            py_version = f"{sys.version_info.major}{sys.version_info.minor}"

        if py_version not in VALID_PY_TARGETS:
            raise ValueError(
                f"The python version {py_version} is not supported. "
                "You can set a python version with the -py or --python-version flag. "
                f"The following versions are supported: {VALID_PY_TARGETS}"
            )

        if py_version != "all":
            object.__setattr__(self, "py_version", f"py{py_version}")

        if not self.known_standard_library:
            object.__setattr__(
                self, "known_standard_library", frozenset(getattr(stdlibs, self.py_version).stdlib)
            )

        if self.multi_line_output == WrapModes.VERTICAL_GRID_GROUPED_NO_COMMA:  # type: ignore
            vertical_grid_grouped = WrapModes.VERTICAL_GRID_GROUPED  # type: ignore
            object.__setattr__(self, "multi_line_output", vertical_grid_grouped)
        if self.force_alphabetical_sort:
            object.__setattr__(self, "force_alphabetical_sort_within_sections", True)
            object.__setattr__(self, "no_sections", True)
            object.__setattr__(self, "lines_between_types", 1)
            object.__setattr__(self, "from_first", True)
        if self.wrap_length > self.line_length:
            raise ValueError(
                "wrap_length must be set lower than or equal to line_length: "
                f"{self.wrap_length} > {self.line_length}."
            )

    def __hash__(self) -> int:
        return id(self)
















_DEFAULT_SETTINGS = {**vars(_Config()), "source": "defaults"}


class Config(_Config):
    def __init__(
        self,
        settings_file: str = "",
        settings_path: str = "",
        config: _Config | None = None,
        **config_overrides: Any,
    ):
    
        # Replaced with provider classes
        self._skip_rules: SkipRules | None = None
        self._sort_resolver: SortResolver | None = None
        self._pattern_matcher: PatternMatcher | None = None



        # Return if config is already defined
        if config:
            self._init_config_from_existing(config, config_overrides)
            return

      

        # All loading, normalisation, and validation is handled by ConfigLoader. 
        loader = ConfigLoader(
            settings_file=settings_file,
            settings_path=settings_path,
            config_overrides=config_overrides,
        )
        combined_config, sources = loader.load()

        # Remove any config values that are used for creating the config object but aren't defined in the dataclass, and construct the FileTypeChecker provider.
        supported_extensions = loader.supported_extensions or SUPPORTED_EXTENSIONS
        blocked_extensions = loader.blocked_extensions or BLOCKED_EXTENSIONS
        self._file_type_checker = FileTypeChecker(
            supported_extensions=frozenset(supported_extensions),
            blocked_extensions=frozenset(blocked_extensions),
        )





        # SortResolver
        self._sort_resolver = SortResolver(sort_order=loader.sort_order)
        combined_config.pop("sort_order", None) # TODO: Do this in the config loader as to not pass it this far!



        # Call const again with the now loaded config
        super().__init__(sources=tuple(sources), **combined_config)


        # ConfigLoader
        self._loader_known_other = loader._known_other
        self._loader_import_headings = loader._import_headings
        self._loader_import_footers = loader._import_footers

        # SortResolver
        # self.sort_resolver.configure(sort_order=combined_config.get("sort_order", "natural"))

        # SkipRules
        self.skip_rules.configure(
            skip=loader.skip,
            extend_skip=loader.extend_skip,
            skip_glob=loader.skip_glob,
            extend_skip_glob=loader.extend_skip_glob,
            skip_gitignore=loader.skip_gitignore,
            git_ls_files=loader.git_ls_files,
            directory=loader.directory,
        )




    # REFACTORED: Extract functions from contructor:


    def _init_config_from_existing(self, config: _Config, overrides: dict[str, Any]) -> None:
        config_vars = vars(config).copy()
        config_vars.update(overrides)
        config_vars["py_version"] = config_vars["py_version"].replace("py", "")
        config_vars.pop("_skip_rules", None)
        config_vars.pop("_sorting_function", None)
        config_vars.pop("_pattern_matcher", None)
        config_vars.pop("_file_type_checker", None)
        config_vars.pop("_loader_known_other", None)
        config_vars.pop("_loader_import_headings", None)
        config_vars.pop("_loader_import_footers", None)
        config_vars.pop("_sort_resolver", None)


        # Strip import_headings/footers from dataclass kwargs as they are not _Config fields. Forward them to the pattern matcher below first though.
        import_headings = config_vars.pop("import_headings", None)
        import_footers = config_vars.pop("import_footers", None)
        
        # FileTypeChecker
        supported_extensions = config_vars.pop("supported_extensions", SUPPORTED_EXTENSIONS)
        blocked_extensions = config_vars.pop("blocked_extensions", BLOCKED_EXTENSIONS)
        self._file_type_checker = FileTypeChecker(
            supported_extensions=frozenset(supported_extensions),
            blocked_extensions=frozenset(blocked_extensions),
        )

        # SortResolver
        sort_order = config_vars.pop("sort_order", "natural")
        self._sort_resolver = SortResolver(sort_order=sort_order)

        super().__init__(**config_vars)


        self._loader_known_other = getattr(config, "_loader_known_other", {})

        # Use overridden headings/footers if givem if not inherit from existing config
        self._loader_import_headings = import_headings if import_headings is not None else getattr(config, "_loader_import_headings", {})
        self._loader_import_footers = import_footers if import_footers is not None else getattr(config, "_loader_import_footers", {})


        self.skip_rules.configure(
            skip=config_vars.get("skip", DEFAULT_SKIP),
            extend_skip=config_vars.get("extend_skip", frozenset()),
            skip_glob=config_vars.get("skip_glob", frozenset()),
            extend_skip_glob=config_vars.get("extend_skip_glob", frozenset()),
            skip_gitignore=config_vars.get("skip_gitignore", False),
            git_ls_files=config_vars.get("git_ls_files", {}),
            directory=config_vars.get("directory", ""),
        )




    



   



   


   

  











    # Replace is_supported_filetype method with FileTypeChecker class (RP2). Also extract function into three methods to handle each var seperately
    @property
    def supported_extensions(self) -> frozenset[str]:
        return self._file_type_checker.supported_extensions

    @property
    def blocked_extensions(self) -> frozenset[str]:
        return self._file_type_checker.blocked_extensions

    def is_supported_filetype(self, file_name: str) -> bool:
        return self._file_type_checker.is_supported_filetype(file_name)


    

    def _get_skip_rules(self) -> SkipRules:
        self.skip_rules.directory = self.directory
        self.skip_rules.git_ls_files = self.git_ls_files
        return self.skip_rules

    def is_skipped(self, file_path: Path) -> bool:
        """Returns True if the file and/or folder should be skipped based on current settings."""
        return self._get_skip_rules().is_skipped(file_path)






    # @property
    # def known_patterns(self) -> list[tuple[Pattern[str], str]]:
    #     if self._known_patterns is not None:
    #         return self._known_patterns

    #     self._known_patterns = []
    #     pattern_sections = [STDLIB] + [section for section in self.sections if section != STDLIB]
    #     for placement in reversed(pattern_sections):
    #         known_placement = KNOWN_SECTION_MAPPING.get(placement, placement).lower()
    #         config_key = f"{KNOWN_PREFIX}{known_placement}"
    #         known_modules = getattr(self, config_key, self.known_other.get(known_placement, ()))
    #         extra_modules = getattr(self, f"extra_{known_placement}", ())
    #         all_modules = set(extra_modules).union(known_modules)
    #         known_patterns = [
    #             pattern
    #             for known_pattern in all_modules
    #             for pattern in self._parse_known_pattern(known_pattern)
    #         ]
    #         for known_pattern in known_patterns:
    #             regexp = "^" + known_pattern.replace("*", ".*").replace("?", ".?") + "$"
    #             self._known_patterns.append((re.compile(regexp), placement))

    #     return self._known_patterns

    # @property
    # def section_comments(self) -> tuple[str, ...]:
    #     if self._section_comments is not None:
    #         return self._section_comments

    #     self._section_comments = tuple(f"# {heading}" for heading in self.import_headings.values())
    #     return self._section_comments

    # @property
    # def section_comments_end(self) -> tuple[str, ...]:
    #     if self._section_comments_end is not None:
    #         return self._section_comments_end

    #     self._section_comments_end = tuple(f"# {footer}" for footer in self.import_footers.values())
    #     return self._section_comments_end



    def _get_pattern_matcher(self) -> PatternMatcher:
        if self._pattern_matcher is None:
            self._pattern_matcher = PatternMatcher(sections=self.sections)
            self._pattern_matcher.configure(
                known_other=self._loader_known_other,
                import_headings=self._loader_import_headings,
                import_footers=self._loader_import_footers,
                directory=self.directory,

                # Pass standard known_* fields so PatternMatcher can build full known_patterns
                known_standard_library=self.known_standard_library,
                known_future_library=self.known_future_library,
                known_third_party=self.known_third_party,
                known_first_party=self.known_first_party,
                known_local_folder=self.known_local_folder,
                extra_standard_library=self.extra_standard_library,
            )
        return self._pattern_matcher
    

    @property
    def import_headings(self) -> dict[str, str]:
        return self._get_pattern_matcher()._import_headings


    @property
    def import_footers(self) -> dict[str, str]:
        return self._get_pattern_matcher()._import_footers


    @property
    def known_other(self) -> dict[str, frozenset[str]]:
        return self._get_pattern_matcher().known_other





    @property
    def known_patterns(self) -> list[tuple[Pattern[str], str]]:
        """Delegates to PatternMatcher provider (RP2)."""
        return self._get_pattern_matcher().known_patterns

    @property
    def section_comments(self) -> tuple[str, ...]:
        """Delegates to PatternMatcher provider (RP2)."""
        return self._get_pattern_matcher().section_comments

    @property
    def section_comments_end(self) -> tuple[str, ...]:
        """Delegates to PatternMatcher provider (RP2)."""
        return self._get_pattern_matcher().section_comments_end

    def _parse_known_pattern(self, pattern: str) -> list[str]:
        """Delegates to PatternMatcher provider (RP2)."""
        return self._get_pattern_matcher()._parse_known_pattern(pattern)
    

 



    @property
    def skips(self) -> frozenset[str]:
        """Merged skip set. Delegates to SkipRules (single source of truth)."""
        return self._get_skip_rules().skips

    @property
    def skip_globs(self) -> frozenset[str]:
        """Merged skip-glob set. Delegates to SkipRules (single source of truth)."""
        return self._get_skip_rules().skip_globs

    # @property
    # def sorting_function(self) -> Callable[..., list[str]]:
    #     if self._sorting_function is not None:
    #         return self._sorting_function

    #     if self.sort_order == "natural":
    #         self._sorting_function = sorting.naturally
    #     elif self.sort_order == "native":
    #         self._sorting_function = sorted
    #     else:
    #         available_sort_orders = ["natural", "native"]
    #         for sort_plugin in entry_points(group="isort.sort_function"):
    #             available_sort_orders.append(sort_plugin.name)
    #             if sort_plugin.name == self.sort_order:
    #                 self._sorting_function = sort_plugin.load()
    #                 break
    #         else:
    #             raise SortingFunctionDoesNotExist(self.sort_order, available_sort_orders)

    #     return self._sorting_function


    @property
    def sort_order(self) -> str:
        return self.sort_resolver.sort_order

    @property
    def sorting_function(self) -> Callable[..., list[str]]:
        """Delegates to SortResolver provider (RP2)."""
        return self.sort_resolver.sorting_function





    # def _parse_known_pattern(self, pattern: str) -> list[str]:
    #     """Expand pattern if identified as a directory and return found sub packages"""
    #     if pattern.endswith(os.path.sep):
    #         patterns = [
    #             filename
    #             for filename in os.listdir(os.path.join(self.directory, pattern))
    #             if os.path.isdir(os.path.join(self.directory, pattern, filename))
    #         ]
    #     else:
    #         patterns = [pattern]

    #     return patterns


def _get_str_to_type_converter(setting_name: str) -> Callable[[str], Any] | type[Any]:
    type_converter: Callable[[str], Any] | type[Any] = type(_DEFAULT_SETTINGS.get(setting_name, ""))
    if type_converter == WrapModes:
        type_converter = wrap_mode_from_string
    return type_converter


def _as_list(value: str) -> list[str]:
    if isinstance(value, list):
        return [item.strip() for item in value]
    filtered = [item.strip() for item in value.replace("\n", ",").split(",") if item.strip()]
    return filtered


def _abspaths(cwd: str, values: Iterable[str]) -> set[str]:
    paths = {
        (
            os.path.join(cwd, value)
            if not value.startswith(os.path.sep) and value.endswith(os.path.sep)
            else value
        )
        for value in values
    }
    return paths


def _find_config(path: str) -> tuple[str, dict[str, Any]]:
    current_directory = path
    tries = 0
    while current_directory and tries < MAX_CONFIG_SEARCH_DEPTH:
        for config_file_name in CONFIG_SOURCES:
            potential_config_file = os.path.join(current_directory, config_file_name)
            if os.path.isfile(potential_config_file):
                config_data: dict[str, Any]
                try:
                    config_data = _get_config_data(
                        potential_config_file, CONFIG_SECTIONS[config_file_name]
                    )
                except Exception:
                    warn(
                        f"Failed to pull configuration information from {potential_config_file}",
                        stacklevel=2,
                    )
                    config_data = {}
                if config_data:
                    return (current_directory, config_data)

        for stop_dir in STOP_CONFIG_SEARCH_ON_DIRS:
            if os.path.isdir(os.path.join(current_directory, stop_dir)):
                return (current_directory, {})

        new_directory = os.path.split(current_directory)[0]
        if new_directory == current_directory:
            break

        current_directory = new_directory
        tries += 1

    return (path, {})


def find_all_configs(path: str) -> Trie:
    """
    Looks for config files in the path provided and in all of its sub-directories.
    Parses and stores any config file encountered in a trie and returns the root of
    the trie
    """
    trie_root = Trie("default", {})

    for dirpath, _, _ in os.walk(path):
        for config_file_name in CONFIG_SOURCES:
            potential_config_file = os.path.join(dirpath, config_file_name)
            if os.path.isfile(potential_config_file):
                config_data: dict[str, Any]
                try:
                    config_data = _get_config_data(
                        potential_config_file, CONFIG_SECTIONS[config_file_name]
                    )
                except Exception:
                    warn(
                        f"Failed to pull configuration information from {potential_config_file}",
                        stacklevel=2,
                    )
                    config_data = {}

                if config_data:
                    trie_root.insert(potential_config_file, config_data)
                    break

    return trie_root


def _get_config_data(file_path: str, sections: tuple[str, ...]) -> dict[str, Any]:
    settings: dict[str, Any] = {}

    if file_path.endswith(".toml"):
        with open(file_path, "rb") as bin_config_file:
            config = tomllib.load(bin_config_file)
        for section in sections:
            config_section = config
            for key in section.split("."):
                config_section = config_section.get(key, {})
            settings.update(config_section)
    else:
        with open(file_path, encoding="utf-8") as config_file:
            if file_path.endswith(".editorconfig"):
                line = "\n"
                last_position = config_file.tell()
                while line:
                    line = config_file.readline()
                    if "[" in line:
                        config_file.seek(last_position)
                        break
                    last_position = config_file.tell()

            config = configparser.ConfigParser(strict=False)
            config.read_file(config_file)
        for section in sections:
            if section.startswith("*.{") and section.endswith("}"):
                extension = section[len("*.{") : -1]
                for config_key in config:
                    if (
                        config_key.startswith("*.{")
                        and config_key.endswith("}")
                        and extension
                        in (text.strip() for text in config_key[len("*.{") : -1].split(","))
                    ):
                        settings.update(config.items(config_key))

            elif config.has_section(section):
                settings.update(config.items(section))

    if settings:
        settings["source"] = file_path

        if file_path.endswith(".editorconfig"):
            indent_style = settings.pop("indent_style", "").strip()
            indent_size = settings.pop("indent_size", "").strip()
            if indent_size == "tab":
                indent_size = settings.pop("tab_width", "").strip()

            if indent_style == "space":
                settings["indent"] = " " * ((indent_size and int(indent_size)) or 4)

            elif indent_style == "tab":
                settings["indent"] = "\t" * ((indent_size and int(indent_size)) or 1)

            max_line_length = settings.pop("max_line_length", "").strip()
            if max_line_length and (max_line_length == "off" or max_line_length.isdigit()):
                settings["line_length"] = (
                    float("inf") if max_line_length == "off" else int(max_line_length)
                )
            settings = {
                key: value
                for key, value in settings.items()
                if key in _DEFAULT_SETTINGS or key.startswith(KNOWN_PREFIX)
            }

        for key, value in settings.items():
            existing_value_type = _get_str_to_type_converter(key)
            if existing_value_type is tuple:
                settings[key] = tuple(_as_list(value))
            elif existing_value_type is frozenset:
                settings[key] = frozenset(_as_list(settings.get(key)))  # type: ignore
            elif existing_value_type is bool:
                # Only some configuration formats support native boolean values.
                if not isinstance(value, bool):
                    value = _as_bool(value)
                settings[key] = value
            elif key.startswith(KNOWN_PREFIX):
                settings[key] = _abspaths(os.path.dirname(file_path), _as_list(value))
            elif key == "force_grid_wrap":
                try:
                    result = existing_value_type(value)
                except ValueError:  # backwards compatibility for true / false force grid wrap
                    result = 0 if value.lower().strip() == "false" else 2
                settings[key] = result
            elif key == "comment_prefix":
                settings[key] = str(value).strip("'").strip('"')
            else:
                settings[key] = existing_value_type(value)

    return settings


def _as_bool(value: str) -> bool:
    """Given a string value that represents True or False, returns the Boolean equivalent.
    Heavily inspired from distutils strtobool.
    """
    try:
        return _STR_BOOLEAN_MAPPING[value.lower()]
    except KeyError:
        raise ValueError(f"invalid truth value {value}")


# def entry_points(group: str) -> "EntryPoints":
#     """Call entry_point after lazy loading it.

#     TODO: The reason for lazy loading here are unknown.
#     """
#     from importlib.metadata import entry_points as ep  # noqa: PLC0415

#     return ep(group=group)


DEFAULT_CONFIG = Config()
