import os
import re
from re import Pattern
from typing import Any

from isort.sections import FIRSTPARTY, FUTURE, LOCALFOLDER, STDLIB, THIRDPARTY


# Constants moved here from settings.py (RP2)
KNOWN_PREFIX = "known_"
KNOWN_SECTION_MAPPING: dict[str, str] = {
    STDLIB: "STANDARD_LIBRARY",
    FUTURE: "FUTURE_LIBRARY",
    FIRSTPARTY: "FIRST_PARTY",
    THIRDPARTY: "THIRD_PARTY",
    LOCALFOLDER: "LOCAL_FOLDER",
}


class PatternMatcher:
    """Resolve known import patterns and comment strings.

    Constructed from the relevant Config fields and used in Config as a provider class, consistent with RP4.
    """

    def __init__(self, sections: tuple[str, ...]) -> None:

        # Store sections needed to build pattern list
        self.sections = sections

        # Initialise all known data as empty. populated via configure()
        self._known_other: dict[str, frozenset[str]] = {}
        self._import_headings: dict[str, str] = {}
        self._import_footers: dict[str, str] = {}
        self._directory: str = ""

        # Caches. None means not yet built
        self._known_patterns: list[tuple[Pattern[str], str]] | None = None
        self._section_comments: tuple[str, ...] | None = None
        self._section_comments_end: tuple[str, ...] | None = None



    def configure(
        self,
        known_other: dict[str, frozenset[str]],
        import_headings: dict[str, str],
        import_footers: dict[str, str],
        directory: str,

        # Standard known_* fields passed in from Config so PatternMatcher owns all data
        known_standard_library: frozenset[str] = frozenset(),
        known_future_library: frozenset[str] = frozenset(),
        known_third_party: frozenset[str] = frozenset(),
        known_first_party: frozenset[str] = frozenset(),
        known_local_folder: frozenset[str] = frozenset(),
        extra_standard_library: frozenset[str] = frozenset(),

    ) -> None:
        # Store custom section data
        self._known_other = dict(known_other)
        self._import_headings = dict(import_headings)
        self._import_footers = dict(import_footers)
        self._directory = directory

        # Merge extra_standard_library into known_standard_library
        self._known_standard_library = known_standard_library | extra_standard_library
        self._known_future_library = known_future_library
        self._known_third_party = known_third_party
        self._known_first_party = known_first_party
        self._known_local_folder = known_local_folder


        # Invalidate caches so next access rebuilds with new data (I spent too much time trying to fix this)
        self._known_patterns = None
        self._section_comments = None
        self._section_comments_end = None





    @property
    def known_other(self) -> dict[str, frozenset[str]]:
        # Returns custom section modules (e.g. known_* fields)
        return self._known_other

    @property
    def known_patterns(self) -> list[tuple[Pattern[str], str]]:
        # Return cached result if already built
        if self._known_patterns is not None:
            return self._known_patterns

        self._known_patterns = []
        pattern_sections = [STDLIB] + [s for s in self.sections if s != STDLIB]

        for placement in reversed(pattern_sections):
            known_placement = KNOWN_SECTION_MAPPING.get(
                placement, placement
            ).lower()

            config_key = f"{KNOWN_PREFIX}{known_placement}"


            # Map section names to their stored known_* frozen sets for section
            known_modules = self._known_other.get(known_placement, ())
            standard_known = {
                "standard_library": self._known_standard_library,
                "future_library": self._known_future_library,
                "third_party": self._known_third_party,
                "first_party": self._known_first_party,
                "local_folder": self._known_local_folder,
            }


            all_modules = set(standard_known.get(known_placement, frozenset())).union(known_modules)

            for known_pattern in all_modules:
                for pattern in self._parse_known_pattern(known_pattern):
                    regexp = "^" + pattern.replace("*", ".*").replace("?", ".?") + "$"
                    self._known_patterns.append((re.compile(regexp), placement))

        return self._known_patterns




    @property
    def section_comments(self) -> tuple[str, ...]:
        # Build and cache heading comment strings (e.g. "# Standard Library")
        if self._section_comments is None:
            self._section_comments = tuple(
                f"# {h}" for h in self._import_headings.values()
            )
        return self._section_comments




    @property
    def section_comments_end(self) -> tuple[str, ...]:
        # Build and cache footer comment strings (e.g. "# End of Standard Library")
        if self._section_comments_end is None:
            self._section_comments_end = tuple(
                f"# {f}" for f in self._import_footers.values()
            )
        return self._section_comments_end






    def _parse_known_pattern(self, pattern: str) -> list[str]:
        #  If pattern is a directory path, expand it to its subdirectory names
        if pattern.endswith(os.path.sep):
            base = os.path.join(self._directory, pattern)
            return [
                f
                for f in os.listdir(base)
                if os.path.isdir(os.path.join(base, f))
            ]
        return [pattern]
    


