"""isort/file_type_checker.py

Encapsulates file type detection logic, extracted from Config.
"""

import os
import re
import stat
from dataclasses import dataclass, field

_SHEBANG_RE = re.compile(rb"^#!.*\bpython[23w]?\b")


@dataclass(frozen=True)
class FileTypeChecker:
    supported_extensions: frozenset
    blocked_extensions: frozenset

    def is_supported_filetype(self, file_name: str) -> bool:
        _root, ext = os.path.splitext(file_name)
        ext = ext.lstrip(".")
        if ext in self.supported_extensions:
            return True
        if ext in self.blocked_extensions:
            return False

        # Skip editor backup files.
        if file_name.endswith("~"):
            return False

        try:
            if stat.S_ISFIFO(os.stat(file_name).st_mode):
                return False
        except OSError:
            pass

        try:
            with open(file_name, "rb") as fp:
                line = fp.readline(100)
        except OSError:
            return False
        return bool(_SHEBANG_RE.match(line))