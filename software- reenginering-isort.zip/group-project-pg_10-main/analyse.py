from pydriller import Repository
import pandas as pd
import matplotlib.pyplot as plt

print("Starting to extract Git history data. Please wait (it may take a few minutes)...")

data = []
for commit in Repository('.').traverse_commits():
    data.append({
        'date': commit.author_date,
        'msg': commit.msg,
        'files_changed': commit.files,
        'lines_added': commit.insertions,
        'lines_deleted': commit.deletions,
    })

df = pd.DataFrame(data)
df['date'] = pd.to_datetime(df['date'], utc=True)
df = df.sort_values('date')
df.to_csv('commit_history.csv', index=False)
print(f"完成！共提取 {len(df)} 个 commits")
print(f"Done! Extracted {len(df)} commits in total.")

# 画代码行数变化折线图  Draw a line chart showing the changes in the number of code lines
df['cumulative_lines'] = (df['lines_added'] - df['lines_deleted']).cumsum()
plt.figure(figsize=(14, 5))
plt.plot(df['date'], df['cumulative_lines'])
plt.title('isort: Lines of Code Over Time')
plt.xlabel('Date')
plt.ylabel('Cumulative Lines')
plt.tight_layout()
plt.savefig('loc_over_time.png')
print("图表已保存：loc_over_time.png")

# 画 commit 类型分布
keywords_refactor = ['refactor', 'clean', 'restructure', 'reorganise', 'move']
keywords_feature = ['add', 'new', 'feature', 'implement']
keywords_fix = ['fix', 'bug', 'patch', 'issue']

def classify(msg):
    msg = msg.lower()
    if any(k in msg for k in keywords_refactor):
        return 'Refactoring'
    elif any(k in msg for k in keywords_feature):
        return 'New Feature'
    elif any(k in msg for k in keywords_fix):
        return 'Bug Fix'
    else:
        return 'Other'

df['type'] = df['msg'].apply(classify)
df['type'].value_counts().plot(kind='bar', color=['#4C72B0','#DD8452','#55A868','#C44E52'])
plt.title('isort: Commit Type Distribution')
plt.xlabel('Type')
plt.ylabel('Count')
plt.tight_layout()
plt.savefig('commit_types.png')
print("图表已保存：commit_types.png")