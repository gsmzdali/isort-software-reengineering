import pandas as pd

df = pd.read_csv('commit_history.csv')
df['date'] = pd.to_datetime(df['date'], utc=True)
df = df.sort_values('date')

# 找2019年删除最多的commits  Find the commits that were deleted the most in 2019
mask_2019 = (df['date'] >= '2019-01-01') & (df['date'] <= '2019-12-31')
print("=== 2019年代码量变化最大的commits ===")
top_2019 = df[mask_2019].nlargest(5, 'lines_deleted')[['date','msg','lines_added','lines_deleted']]
for _, row in top_2019.iterrows():
    print(f"\n日期: {row['date']}")
    print(f"消息: {row['msg'][:200]}")
    print(f"新增: {row['lines_added']} | 删除: {row['lines_deleted']}")

# 找2020-2021年增加最多的commits  Find the commits that saw the greatest increase in 2020-2021
mask_2020 = (df['date'] >= '2020-01-01') & (df['date'] <= '2021-12-31')
print("\n\n=== 2020-2021年代码量增加最大的commits ===")
top_2020 = df[mask_2020].nlargest(5, 'lines_added')[['date','msg','lines_added','lines_deleted']]
for _, row in top_2020.iterrows():
    print(f"\n日期: {row['date']}")
    print(f"消息: {row['msg'][:200]}")
    print(f"新增: {row['lines_added']} | 删除: {row['lines_deleted']}")