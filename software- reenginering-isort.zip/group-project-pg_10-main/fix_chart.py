import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('commit_history.csv')

keywords_refactor = ['refactor', 'clean', 'restructure', 'reorganise', 'move']
keywords_feature = ['add', 'new', 'feature', 'implement']
keywords_fix = ['fix', 'bug', 'patch', 'issue']

def classify(msg):
    msg = str(msg).lower()
    if any(k in msg for k in keywords_refactor):
        return 'Refactoring'
    elif any(k in msg for k in keywords_feature):
        return 'New Feature'
    elif any(k in msg for k in keywords_fix):
        return 'Bug Fix'
    else:
        return 'Other'

df['type'] = df['msg'].apply(classify)
counts = df['type'].value_counts()
print(counts)

counts.plot(kind='bar', color=['#4C72B0','#DD8452','#55A868','#C44E52'])
plt.title('isort: Commit Type Distribution')
plt.xlabel('Type')
plt.ylabel('Number of Commits')
plt.tight_layout()
plt.savefig('commit_types_fixed.png')
print("修复版图表已保存")